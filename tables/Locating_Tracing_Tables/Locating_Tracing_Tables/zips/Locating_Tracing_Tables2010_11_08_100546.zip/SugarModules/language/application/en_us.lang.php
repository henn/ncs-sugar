<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

$app_list_strings['moduleList']['LTT_ADDRESS'] = 'ADDRESS';
$app_list_strings['moduleList']['LTT_EMAIL'] = 'EMAIL';
$app_list_strings['moduleList']['LTT_TELEPHONE'] = 'TELEPHONE';
$app_list_strings['COMMUNICATION_RANK_CL1']['Primary'] = 'Primary';
$app_list_strings['COMMUNICATION_RANK_CL1']['Secondary'] = 'Secondary';
$app_list_strings['COMMUNICATION_RANK_CL1']['Invalid'] = 'Invalid';
$app_list_strings['COMMUNICATION_RANK_CL1']['Duplicate'] = 'Duplicate';
$app_list_strings['COMMUNICATION_RANK_CL1']['Other'] = 'Other';
$app_list_strings['INFORMATION_SOURCE_CL2']['Person_Self'] = 'Person_Self';
$app_list_strings['INFORMATION_SOURCE_CL2']['Provider'] = 'Provider';
$app_list_strings['INFORMATION_SOURCE_CL2']['Household_Member'] = 'Household_Member';
$app_list_strings['INFORMATION_SOURCE_CL2']['Other_Person_Associated'] = 'Other_Person_Associated';
$app_list_strings['INFORMATION_SOURCE_CL2']['Web'] = 'Web';
$app_list_strings['INFORMATION_SOURCE_CL2']['Returned_Mail'] = 'Returned_Mail';
$app_list_strings['INFORMATION_SOURCE_CL2']['Tracing_Vendor'] = 'Tracing_Vendor';
$app_list_strings['INFORMATION_SOURCE_CL2']['Other'] = 'Other';
$app_list_strings['EMAIL_TYPE_CL1']['Personal'] = 'Personal';
$app_list_strings['EMAIL_TYPE_CL1']['Work'] = 'Work';
$app_list_strings['EMAIL_TYPE_CL1']['Family_Shared'] = 'Family_Shared';
$app_list_strings['EMAIL_TYPE_CL1']['Refused'] = 'Refused';
$app_list_strings['EMAIL_TYPE_CL1']['Other'] = 'Other';
$app_list_strings['EMAIL_TYPE_CL1']['Unknown'] = 'Unknown';
$app_list_strings['CONFIRM_TYPE_CL2']['Yes'] = 'Yes';
$app_list_strings['CONFIRM_TYPE_CL2']['No'] = 'No';
$app_list_strings['STATE_CL1']['ALABAMA  '] = 'ALABAMA  ';
$app_list_strings['STATE_CL1']['ALASKA '] = 'ALASKA ';
$app_list_strings['STATE_CL1']['ARIZONA '] = 'ARIZONA ';
$app_list_strings['STATE_CL1']['ARKANSAS '] = 'ARKANSAS ';
$app_list_strings['STATE_CL1']['CALIFORNIA '] = 'CALIFORNIA ';
$app_list_strings['STATE_CL1']['COLORADO '] = 'COLORADO ';
$app_list_strings['STATE_CL1']['CONNECTICUT '] = 'CONNECTICUT ';
$app_list_strings['STATE_CL1']['DELAWARE '] = 'DELAWARE ';
$app_list_strings['STATE_CL1']['DISTRICT OF COLUMBIA '] = 'DISTRICT OF COLUMBIA ';
$app_list_strings['STATE_CL1']['FLORIDA '] = 'FLORIDA ';
$app_list_strings['STATE_CL1']['GEORGIA '] = 'GEORGIA ';
$app_list_strings['STATE_CL1']['HAWAII '] = 'HAWAII ';
$app_list_strings['STATE_CL1']['IDAHO '] = 'IDAHO ';
$app_list_strings['STATE_CL1']['ILLINOIS '] = 'ILLINOIS ';
$app_list_strings['STATE_CL1']['INDIANA '] = 'INDIANA ';
$app_list_strings['STATE_CL1']['IOWA '] = 'IOWA ';
$app_list_strings['STATE_CL1']['KANSAS '] = 'KANSAS ';
$app_list_strings['STATE_CL1']['KENTUCKY '] = 'KENTUCKY ';
$app_list_strings['STATE_CL1']['LOUISIANA '] = 'LOUISIANA ';
$app_list_strings['STATE_CL1']['MAINE '] = 'MAINE ';
$app_list_strings['STATE_CL1']['MARYLAND '] = 'MARYLAND ';
$app_list_strings['STATE_CL1']['MASSACHUSETTS '] = 'MASSACHUSETTS ';
$app_list_strings['STATE_CL1']['MICHIGAN '] = 'MICHIGAN ';
$app_list_strings['STATE_CL1']['MINNESOTA '] = 'MINNESOTA ';
$app_list_strings['STATE_CL1']['MISSISSIPPI '] = 'MISSISSIPPI ';
$app_list_strings['STATE_CL1']['MISSOURI '] = 'MISSOURI ';
$app_list_strings['STATE_CL1']['MONTANA '] = 'MONTANA ';
$app_list_strings['STATE_CL1']['NEBRASKA '] = 'NEBRASKA ';
$app_list_strings['STATE_CL1']['NEVADA '] = 'NEVADA ';
$app_list_strings['STATE_CL1']['NEW HAMPSHIRE '] = 'NEW HAMPSHIRE ';
$app_list_strings['STATE_CL1']['NEW JERSEY '] = 'NEW JERSEY ';
$app_list_strings['STATE_CL1']['NEW MEXICO '] = 'NEW MEXICO ';
$app_list_strings['STATE_CL1']['NEW YORK '] = 'NEW YORK ';
$app_list_strings['STATE_CL1']['NORTH CAROLINA '] = 'NORTH CAROLINA ';
$app_list_strings['STATE_CL1']['NORTH DAKOTA '] = 'NORTH DAKOTA ';
$app_list_strings['STATE_CL1']['OHIO '] = 'OHIO ';
$app_list_strings['STATE_CL1']['OKLAHOMA '] = 'OKLAHOMA ';
$app_list_strings['STATE_CL1']['OREGON '] = 'OREGON ';
$app_list_strings['STATE_CL1']['PENNSYLVANIA '] = 'PENNSYLVANIA ';
$app_list_strings['STATE_CL1']['RHODE ISLAND '] = 'RHODE ISLAND ';
$app_list_strings['STATE_CL1']['SOUTH CAROLINA '] = 'SOUTH CAROLINA ';
$app_list_strings['STATE_CL1']['SOUTH DAKOTA '] = 'SOUTH DAKOTA ';
$app_list_strings['STATE_CL1']['TENNESSEE '] = 'TENNESSEE ';
$app_list_strings['STATE_CL1']['TEXAS '] = 'TEXAS ';
$app_list_strings['STATE_CL1']['UTAH '] = 'UTAH ';
$app_list_strings['STATE_CL1']['VERMONT '] = 'VERMONT ';
$app_list_strings['STATE_CL1']['VIRGINIA '] = 'VIRGINIA ';
$app_list_strings['STATE_CL1']['WASHINGTON '] = 'WASHINGTON ';
$app_list_strings['STATE_CL1']['WEST VIRGINIA '] = 'WEST VIRGINIA ';
$app_list_strings['STATE_CL1']['WISCONSIN '] = 'WISCONSIN ';
$app_list_strings['STATE_CL1']['WYOMING '] = 'WYOMING ';
$app_list_strings['STATE_CL1']['Unknown'] = 'Unknown';
